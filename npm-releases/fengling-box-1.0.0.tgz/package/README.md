# fengling-box 枫铃工具箱

多功能命令行工具箱，命令统一用 `flb` 调用。

## 安装

```bash
npm install -g fengling-box
```

## 功能模块

### 🔍 搜索 (search / s)

用户**显式选择**搜索源，不自动路由。

```bash
flb search <engine> <query>

# 示例
flb search baidu "OpenCode Go教程"
flb search github "fengling-box"
flb search bilibili "Flux.2 Klein"
flb search arxiv "speculative decoding" --limit 5
flb search weibo hot
flb search moegirl "德国骨科"
flb search tavily "7月1日 AI新闻" --format json

# 列出所有可用搜索源
flb search engines
flb search engines --detail
```

**可用搜索源（36个）：**

| 类别 | 搜索源 |
|------|--------|
| 通用 | baidu, bing, duckduckgo, brave*, yandex, google* |
| AI聚合 | tavily*, exa* |
| 中文 | weibo, zhihu, bilibili, douyin, toutiao |
| 新闻 | xinhua, cctv, thepaper, kr36, huxiu, ithome, cls |
| 技术 | github, npm, pypi, stackoverflow |
| 学术 | arxiv, wikipedia, moegirl, semanticscholar, googlescholar |
| 电商 | taobao, jd, pdd |
| 娱乐 | douban, imdb |
| 百科 | baidubaike |

`*` 需要配置 API Key

### 📁 文件 (file)

```bash
flb file rename ./photos --prefix "trip_" --start 1
flb file rename ./docs --lower --dry-run
flb file list ./folder --ext jpg,png --size
flb file copy ./src ./dst --ext pdf
```

### 🖼 图片 (image)

```bash
flb image compress ./photos --quality 80 --out ./compressed
flb image convert ./image.png --to webp
flb image resize ./photo.jpg --width 800
flb image watermark ./photo.jpg --text "枫铃" --position bottom-right
flb image info ./photo.jpg
```

### 📊 数据 (data)

```bash
flb data csv ./data.csv --info
flb data csv ./data.csv --col 1,2,3 --out result.csv
flb data excel ./data.xlsx --sheet Sheet1 --out result.csv
flb data text ./file.txt --trim --dedup --empty --out result.txt
flb data json ./data.json --pretty --query "data[0].name"
```

### ✅ 信源核实 (verify / v)

```bash
flb verify https://www.xinhuanet.com/xxx
flb verify https://a.com https://b.com --detail
flb v https://toutiao.com/xxx
```

### ⚙️ 配置 (config)

```bash
flb config set tavily.key tvly-xxxxx
flb config set exa.key 4b425c7f-xxxx
flb config set github.token ghp_xxxxx
flb config set brave.key BSAxxxxx
flb config set google.key AIzaSyxxxxx
flb config set google.cx 012345678xxx
flb config list
flb config get tavily.key
flb config delete tavily.key
```

## 参数说明

| 参数 | 说明 |
|------|------|
| `--limit <n>` | 返回结果数量，默认10 |
| `--format text\|json\|table` | 输出格式，默认text |
| `--type <type>` | 搜索类型（部分源支持，如bilibili的video/upuser） |
| `--dry-run` | 预览模式，不实际执行 |

## License

MIT
