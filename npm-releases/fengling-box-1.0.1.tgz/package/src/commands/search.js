import chalk from 'chalk'
import ora from 'ora'
import { getEngine, listEngines } from '../engines/index.js'
import { printResults, printError, printInfo } from '../utils/output.js'
import { table } from 'table'

export function registerSearch(program) {
  const search = program
    .command('search')
    .description('多源聚合搜索（用户显式选择搜索源）')
    .argument('[engine]', '搜索源名称，输入 engines 列出所有可用源')
    .argument('[query...]', '搜索关键词')
    .option('-l, --limit <n>', '返回结果数量', '10')
    .option('-f, --format <fmt>', '输出格式: text/json/table', 'text')
    .option('-t, --type <type>', '搜索类型（部分搜索源支持）')
    .option('--detail', '显示详细信息（配合 engines 使用）')
    .addHelpText('after', `
示例:
  flb search baidu "OpenCode Go使用教程"
  flb search github "qwen coder" --limit 5
  flb search bilibili "Flux.2 Klein" --type video
  flb search arxiv "speculative decoding" --limit 5
  flb search weibo hot
  flb search tavily "7月1日 AI大模型" --format json
  flb search engines
  flb search engines --detail
`)
    .action(async (engineName, queryParts, opts) => {
      if (!engineName || engineName === 'engines') {
        const list = listEngines()
        if (opts.detail) {
          const headers = [
            chalk.bold('名称'),
            chalk.bold('说明'),
            chalk.bold('需要Key'),
            chalk.bold('稳定性'),
          ]
          const rows = list.map(e => [
            chalk.cyan(e.name),
            e.description,
            e.requiresKey ? chalk.yellow('✓') : chalk.green('✗'),
            e.stability === 'stable' ? chalk.green('稳定') :
              e.stability === 'unstable' ? chalk.yellow('不稳定') :
              chalk.red('实验性'),
          ])
          console.log(table([headers, ...rows]))
        } else {
          const names = list.map(e => chalk.cyan(e.name)).join(', ')
          console.log(chalk.bold('\n可用搜索源:\n'))
          console.log(names)
          console.log(chalk.gray('\n使用 --detail 查看详细信息\n'))
        }
        return
      }
      const query = queryParts.join(' ')
      if (!query) return printError('请输入搜索关键词')
      const limit = parseInt(opts.limit) || 10
      const spinner = ora(`正在搜索 [${engineName}]: ${query}`).start()
      try {
        const engine = getEngine(engineName)
        const results = await engine.search(query, { limit, type: opts.type })
        spinner.stop()
        printResults(results, engineName, opts.format)
      } catch (err) {
        spinner.stop()
        printError(err.message)
        process.exit(1)
      }
    })



  // 直接 flb search <engine> <query> 形式
  program.hook('preSubcommand', (thisCommand, subCommand) => {})

  // 注册为 flb search <engine> <query> 的直接形式
  program
    .command('s <engine> <query...>', { hidden: true })
    .description('search的快捷命令')
    .option('-l, --limit <n>', '返回结果数量', '10')
    .option('-f, --format <fmt>', '输出格式: text/json/table', 'text')
    .option('-t, --type <type>', '搜索类型')
    .action(async (engineName, queryParts, opts) => {
      const query = queryParts.join(' ')
      const limit = parseInt(opts.limit) || 10
      const spinner = ora(`正在搜索 [${engineName}]: ${query}`).start()
      try {
        const engine = getEngine(engineName)
        const results = await engine.search(query, { limit, type: opts.type })
        spinner.stop()
        printResults(results, engineName, opts.format)
      } catch (err) {
        spinner.stop()
        printError(err.message)
        process.exit(1)
      }
    })
}
